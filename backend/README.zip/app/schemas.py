"""
Pydantic-Schemas: legen fest, welche Daten die API annimmt (…In)
und welche sie zurueckgibt (…Out). Falsche Eingaben -> automatisch 422.
"""

from datetime import date, datetime
from datetime import time as time_type
from typing import Literal, Optional

from pydantic import BaseModel, ConfigDict, Field, model_validator

from app import models


# ---------------- Auth / Benutzer ----------------
class TokenOut(BaseModel):
    access_token: str
    token_type: str = "bearer"
    role: str
    user_id: int
    username: str
    first_name: str
    last_name: str


class UserOut(BaseModel):
    id: int
    username: str
    first_name: str
    last_name: str
    email: str
    role: str
    profile_image: str | None = None   # V4.5, Bild unter GET /users/avatar/{profile_image}


EMAIL_PATTERN = r"^[^@\s]+@[^@\s]+\.[^@\s]+$"


class RegisterIn(BaseModel):
    first_name: str = Field(min_length=1, max_length=100)
    last_name: str = Field(min_length=1, max_length=100)
    username: str = Field(min_length=3, max_length=50)
    email: str = Field(pattern=EMAIL_PATTERN, max_length=255)
    password: str = Field(min_length=8, max_length=72)   # bcrypt nutzt max. 72 Bytes
    # Selbst registrieren duerfen sich nur SchuelerInnen. "lehrkraft" -> 403 (legt der Admin an),
    # "admin" -> 422. Feld darf fehlen (= schueler).
    role: Literal["schueler", "lehrkraft"] = "schueler"


class UserCreateIn(RegisterIn):
    """POST /users (nur admin): Konto fuer SchuelerIn oder Lehrkraft anlegen."""
    role: Literal["schueler", "lehrkraft"]


class ProfileUpdateIn(BaseModel):
    """PATCH /users/me: E-Mail und/oder Username aendern (gleiche Regeln wie bei Register).
    Andere Felder im Body (z. B. "role") werden ignoriert, nie uebernommen."""
    email: Optional[str] = Field(default=None, pattern=EMAIL_PATTERN, max_length=255)
    username: Optional[str] = Field(default=None, min_length=3, max_length=50)

    @model_validator(mode="after")
    def _mindestens_ein_feld(self):
        if self.email is None and self.username is None:
            raise ValueError("email oder username angeben")
        return self


class PasswordChangeIn(BaseModel):
    """POST /users/me/password"""
    current_password: str = Field(min_length=1, max_length=72)
    new_password: str = Field(min_length=8, max_length=72)   # wie bei Register


class AvatarOut(BaseModel):
    profile_image: str


# ---------------- Noten ----------------
class GradeIn(BaseModel):
    student_id: int
    class_subject_id: int
    category: Literal[models.GRADE_CATEGORIES]  # type: ignore[valid-type]
    value: float = Field(ge=4, le=10, description="Note 4-10")
    weight: float = Field(default=1.0, gt=0)
    date: Optional[date] = None
    homework_id: Optional[int] = None


class GradeOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    student_id: int
    class_subject_id: int
    category: str
    weight: float
    value: float
    date: date


# ---------------- Hausaufgaben ----------------
class HomeworkOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    class_subject_id: int
    description: str
    due_date: datetime


class HomeworkConfirmIn(BaseModel):
    homework_id: int


# ---------------- Anwesenheit ----------------
class MinutesMissedMixin(BaseModel):
    """V4.8: versaeumte Minuten. Nur bei 'verspaetet' von der Lehrkraft anzugeben;
    bei 'anwesend' (0) und 'abwesend' (ganze Stunde) setzt die API den Wert selbst.
    Fehlt die Angabe bei 'verspaetet', wird NULL gespeichert (= Minuten unbekannt)."""
    minutes_missed: Optional[int] = Field(default=None, ge=1, le=600)

    @model_validator(mode="after")
    def _only_for_late(self):
        if self.status != "verspaetet":
            self.minutes_missed = None      # wird in der API aus dem Status abgeleitet
        return self


class AttendanceIn(MinutesMissedMixin):
    student_id: int
    lesson_id: int
    status: Literal[models.ATTENDANCE_STATUS]  # type: ignore[valid-type]


class AttendanceOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    student_id: int
    lesson_id: int
    status: str
    minutes_missed: Optional[int] = None      # V4.8
    excuse_id: Optional[int] = None


# ---------------- Anwesenheit pro Stunde (V2.8) ----------------
# Eine "Stunde" = timetable-Eintrag (Fach + Wochentag + Beginn) + Datum -> Zeile in lessons
class LessonSlotOut(BaseModel):
    timetable_id: int
    weekday: str
    start_time: time_type
    end_time: time_type
    room: Optional[str] = None


class LessonStudentOut(BaseModel):
    student_id: int
    first_name: str
    last_name: str
    username: str
    status: Optional[str] = None          # None = noch nicht erfasst
    minutes_missed: Optional[int] = None  # V4.8
    excuse_id: Optional[int] = None
    enrolled: bool = True                 # False = nicht mehr im Fach, hat aber einen Eintrag


class LessonAttendanceOut(BaseModel):
    class_subject_id: int
    date: date
    start_time: time_type
    end_time: time_type
    room: Optional[str] = None
    lesson_id: Optional[int] = None       # None = fuer diese Stunde wurde noch nichts erfasst
    cancelled: bool = False
    students: list[LessonStudentOut]


class AttendanceEntryIn(MinutesMissedMixin):
    student_id: int
    status: Literal[models.ATTENDANCE_STATUS]  # type: ignore[valid-type]


class LessonAttendanceIn(BaseModel):
    class_subject_id: int
    date: date
    start_time: time_type
    entries: list[AttendanceEntryIn] = Field(min_length=1, max_length=200)


class LessonHistoryOut(BaseModel):
    lesson_id: int
    date: date
    start_time: time_type
    end_time: time_type
    present_count: int
    absent_count: int
    late_count: int


# ---------------- Fehlstunden und Entschuldigungen (V4.6) ----------------
class AbsenceOut(BaseModel):
    attendance_id: int
    date: date
    start_time: time_type
    end_time: time_type
    subject_name: str
    status: str                       # abwesend / verspaetet
    excuse_id: Optional[int] = None
    excuse_status: Optional[str] = None   # null, pending, accepted, rejected


class ExcuseIn(BaseModel):
    reason: str = Field(min_length=1, max_length=2000)
    attendance_ids: list[int] = Field(min_length=1, max_length=200)


class ExcuseReviewIn(BaseModel):
    status: Literal["accepted", "rejected"]
    teacher_comment: Optional[str] = Field(default=None, max_length=2000)


class ExcuseAttachmentOut(BaseModel):
    id: int
    original_name: str
    size_bytes: int


class ExcuseOut(BaseModel):
    id: int
    student_id: int
    student_name: str
    class_name: Optional[str] = None
    date_from: date
    date_to: date
    reason: Optional[str] = None
    status: str
    teacher_comment: Optional[str] = None
    reviewed_by: Optional[int] = None
    reviewed_by_name: Optional[str] = None
    reviewed_at: Optional[datetime] = None
    submitted_at: datetime
    absences: list[AbsenceOut]
    attachments: list[ExcuseAttachmentOut] = []      # V4.9


# ---------------- Stundenplan ----------------
class TimetableOut(BaseModel):
    id: int
    class_subject_id: int
    subject: str
    class_name: str
    weekday: str
    start_time: str
    end_time: str
    room: Optional[str] = None


# ---------------- Quiz ----------------
class QuizSubmitIn(BaseModel):
    quiz_id: int
    score: int = Field(ge=0)


# ---------------- Klassen / SchuelerInnen ----------------
class ClassOut(BaseModel):
    id: int
    name: str
    school_year_id: int
    school_year: str


class StudentOut(BaseModel):
    id: int
    first_name: str
    last_name: str
    username: str
    class_name: Optional[str] = None


class StudentIdIn(BaseModel):
    student_id: int


# ---------------- Faecher (= class_subjects) ----------------
class SubjectOut(BaseModel):
    id: int                      # class_subjects.id
    teacher_id: int
    subject_name: str
    class_name: str
    teacher_name: str
    file_count: int
    student_count: int


class SubjectCreateIn(BaseModel):
    class_id: int
    name: str = Field(min_length=1, max_length=150)


# ---------------- Materialien ----------------
class MaterialOut(BaseModel):
    id: int
    title: str
    original_name: str
    size_bytes: int
    uploaded_at: Optional[datetime]
    ext: str


class RecentMaterialOut(BaseModel):
    id: int
    title: str
    uploaded_at: Optional[datetime]
    subject_name: str
    ext: str


class UploadConfigOut(BaseModel):
    allowed_extensions: list[str]
    max_size_mb: int


# ---------------- allgemein ----------------
class StatusOut(BaseModel):
    status: str
    detail: Optional[dict] = None


# =====================================================================
# Quiz (V4.4) - Formate wie in docs/QUIZ_API.md
# =====================================================================
class QuizCreateIn(BaseModel):
    title: str = Field(min_length=1, max_length=150)
    description: Optional[str] = None


class QuizUpdateIn(BaseModel):
    title: Optional[str] = Field(default=None, min_length=1, max_length=150)
    description: Optional[str] = None
    is_published: Optional[bool] = None


class OptionIn(BaseModel):
    option_text: str = Field(min_length=1, max_length=500)
    is_correct: bool = False


class QuestionIn(BaseModel):
    """mc: options · tf: correct · gap: gaps (akzeptierte Antworten pro {{n}})"""
    type: Literal["mc", "tf", "gap"]
    question_text: str = Field(min_length=1, max_length=5000)
    points: int = Field(default=1, ge=1, le=100)
    options: Optional[list[OptionIn]] = None
    correct: Optional[bool] = None
    gaps: Optional[list[list[str]]] = None


class OptionTeacherOut(BaseModel):
    id: int
    option_text: str
    is_correct: bool
    gap_index: Optional[int]
    position: int


class QuestionTeacherOut(BaseModel):
    id: int
    position: int
    type: str
    points: int
    question_text: str
    options: list[OptionTeacherOut]


class QuizTeacherOut(BaseModel):
    id: int
    class_subject_id: int
    title: str
    description: Optional[str]
    is_published: bool
    locked: bool
    max_score: int
    questions: list[QuestionTeacherOut]


class QuizListTeacherOut(BaseModel):
    id: int
    title: str
    description: Optional[str]
    is_published: bool
    locked: bool
    question_count: int
    max_score: int
    attempt_count: int
    created_at: Optional[datetime]


class MyResultShortOut(BaseModel):
    score: int
    max_score: int
    submitted_at: Optional[datetime]


class QuizListStudentOut(BaseModel):
    id: int
    title: str
    description: Optional[str]
    question_count: int
    max_score: int
    my_result: Optional[MyResultShortOut]


class OptionStudentOut(BaseModel):
    id: int
    option_text: str


class QuestionStudentOut(BaseModel):
    id: int
    position: int
    type: str
    points: int
    question_text: str
    options: Optional[list[OptionStudentOut]] = None
    gap_count: Optional[int] = None


class QuizTakeOut(BaseModel):
    id: int
    title: str
    description: Optional[str]
    max_score: int
    questions: list[QuestionStudentOut]


class AnswerIn(BaseModel):
    question_id: int
    option_ids: Optional[list[int]] = None
    gaps: Optional[list[str]] = None


class QuizSubmitAnswersIn(BaseModel):
    answers: list[AnswerIn] = Field(default_factory=list)


class QuestionResultOut(BaseModel):
    question_id: int
    question_text: str
    correct: bool
    points_awarded: int


class QuizResultOut(BaseModel):
    score: int
    max_score: int
    submitted_at: Optional[datetime]
    questions: list[QuestionResultOut]


class AttemptOut(BaseModel):
    student_id: int
    first_name: str
    last_name: str
    username: str
    score: int
    max_score: Optional[int]
    submitted_at: Optional[datetime]
