"""
EduDevice - Testdaten fuer Schema V4.6
Legt Beispieldaten an, damit das Frontend (Orest) echte Antworten von der API bekommt.
Kann mehrmals ausgefuehrt werden - legt nichts doppelt an.
Ausfuehren (im backend-Ordner):  python -m scripts.seed

Test-Logins (NUR fuer Entwicklung) - Username oder E-Mail:
  admin     / admin@edudevice.at    / admin123
  alehrer   / lehrer@edudevice.at   / lehrer123
  tschueler / schueler@edudevice.at / schueler123
"""

from datetime import date, datetime, time, timedelta

from app.core.database import SessionLocal
from app.core.security import hash_password
from app import models as m


def get_or_create(db, model, lookup: dict, extra: dict | None = None):
    obj = db.query(model).filter_by(**lookup).first()
    if obj is None:
        obj = model(**lookup, **(extra or {}))
        db.add(obj)
        db.flush()
    return obj


def seed():
    db = SessionLocal()
    try:
        admin = get_or_create(db, m.User, {"username": "admin"},
                              {"first_name": "Admin", "last_name": "EduDevice", "email": "admin@edudevice.at", "role": "admin",
                               "password_hash": hash_password("admin123")})
        lehrer = get_or_create(db, m.User, {"username": "alehrer"},
                               {"first_name": "Anna", "last_name": "Lehrer", "email": "lehrer@edudevice.at", "role": "lehrkraft",
                                "password_hash": hash_password("lehrer123")})
        schueler = get_or_create(db, m.User, {"username": "tschueler"},
                                 {"first_name": "Test", "last_name": "Schueler", "email": "schueler@edudevice.at", "role": "schueler",
                                  "password_hash": hash_password("schueler123")})

        jahr = get_or_create(db, m.SchoolYear, {"label": "2026/27"},
                             {"start_date": date(2026, 9, 1), "end_date": date(2027, 6, 30)})
        klasse = get_or_create(db, m.SchoolClass, {"school_year_id": jahr.id, "name": "4A"})
        get_or_create(db, m.StudentClass, {"student_id": schueler.id, "class_id": klasse.id})

        mathe = get_or_create(db, m.Subject, {"name": "Mathematik"})
        mathe_4a = get_or_create(db, m.ClassSubject,
                                 {"class_id": klasse.id, "subject_id": mathe.id},
                                 {"teacher_id": lehrer.id})

        # V4.3: SchuelerIn ist im Fach eingetragen (sonst sieht er/sie es in der WebApp nicht)
        get_or_create(db, m.ClassSubjectStudent, {"class_subject_id": mathe_4a.id, "student_id": schueler.id})

        stunde = get_or_create(db, m.TimetableEntry,
                               {"class_subject_id": mathe_4a.id, "weekday": "Mo",
                                "start_time": time(8, 0)},
                               {"end_time": time(8, 50), "room": "A101"})
        lesson = get_or_create(db, m.Lesson, {"timetable_id": stunde.id, "date": date(2026, 9, 28)})

        # V4.6: Klassenvorstand der 4A + ein paar Fehlstunden zum Entschuldigen
        if klasse.class_teacher_id is None:
            klasse.class_teacher_id = lehrer.id
        # V4.8: mit versaeumten Minuten (Stunde 8:00-8:50 -> abwesend = 50, einmal 10 Minuten zu spaet)
        for tag, status, minuten in ((date(2026, 10, 5), "abwesend", 50), (date(2026, 10, 12), "verspaetet", 10),
                                     (date(2026, 10, 19), "abwesend", 50)):
            stunde_x = get_or_create(db, m.Lesson, {"timetable_id": stunde.id, "date": tag})
            get_or_create(db, m.Attendance, {"student_id": schueler.id, "lesson_id": stunde_x.id},
                          {"status": status, "minutes_missed": minuten})
        # V2.8: zwei Stunden mit Anwesenheit fuer die Verlaufsansicht
        for tag in (date(2026, 10, 26), date(2026, 11, 2)):
            stunde_x = get_or_create(db, m.Lesson, {"timetable_id": stunde.id, "date": tag})
            get_or_create(db, m.Attendance, {"student_id": schueler.id, "lesson_id": stunde_x.id},
                          {"status": "anwesend", "minutes_missed": 0})

        hw = get_or_create(db, m.Homework,
                           {"class_subject_id": mathe_4a.id, "description": "Buch S. 12, Aufgaben 1-5"},
                           {"due_date": datetime(2026, 10, 5, 8, 0)})

        if not db.query(m.Grade).filter_by(student_id=schueler.id).first():
            db.add(m.Grade(student_id=schueler.id, class_subject_id=mathe_4a.id,
                           category="mini_test", value=9, weight=1.0, date=date(2026, 9, 21)))

        quiz = get_or_create(db, m.Quiz, {"title": "Bruchrechnen", "class_subject_id": mathe_4a.id},
                             {"created_by": lehrer.id, "is_published": False})

        db.commit()
        print("Testdaten bereit:")
        print(f"  admin     / admin123     (user_id={admin.id})")
        print(f"  alehrer   / lehrer123    (user_id={lehrer.id})")
        print(f"  tschueler / schueler123  (user_id={schueler.id})")
        print(f"  Klasse 4A (class_id={klasse.id}), Mathematik (subject_id={mathe.id}), "
              f"class_subject_id={mathe_4a.id}")
        print(f"  Stunde lesson_id={lesson.id} am 28.09.2026, Hausaufgabe id={hw.id}, Quiz id={quiz.id}")
        print("  Klassenvorstand 4A = alehrer, tschueler hat 3 Fehlstunden (05.10., 12.10., 19.10.)")
        print("  Mathe 4A: Montag 08:00, Anwesenheit erfasst am 05.10., 12.10., 19.10., 26.10., 02.11.")
    except Exception:
        db.rollback()
        raise
    finally:
        db.close()


if __name__ == "__main__":
    seed()
